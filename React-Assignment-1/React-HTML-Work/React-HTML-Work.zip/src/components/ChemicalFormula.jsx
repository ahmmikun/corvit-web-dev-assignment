function ChemicalFormula() {
  return (
    <div>
      <p>
        4(MgCO<sub>3</sub>).Mg(OH<sub>2</sub>).4H<sub>2</sub>O
      </p>

      <p>
        MgCO<sub>3</sub>.3H<sub>2</sub>O
      </p>

      <p>
        Na<sub>2</sub>CO<sub>3</sub>.NaHCO<sub>3</sub>.H<sub>2</sub>O
      </p>

      <p>
        Na<sub>2</sub>CO<sub>3</sub>.H<sub>2</sub>O
      </p>
    </div>
  );
}

export default ChemicalFormula;