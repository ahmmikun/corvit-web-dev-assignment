function CheeseTable() {
  return (
    <div>
      <h1>Tables</h1>

      <table border="1" cellPadding="8" style={{ borderCollapse: "collapse" }}>
        <thead>
          <tr>
            <th colSpan="12">
              Mineral content of common cheeses, DV% per 100 g
            </th>
          </tr>

          <tr>
            <th></th>
            <th>Cl</th>
            <th>Ca</th>
            <th>Fe</th>
            <th>Mg</th>
            <th>P</th>
            <th>K</th>
            <th>Na</th>
            <th>Zn</th>
            <th>Cu</th>
            <th>Mn</th>
            <th>Se</th>
          </tr>
        </thead>

        <tbody>
          <tr>
            <th>Swiss</th>
            <td>2.8</td>
            <td>79</td>
            <td>10</td>
            <td>1</td>
            <td>57</td>
            <td>2</td>
            <td>8</td>
            <td>29</td>
            <td>2</td>
            <td>0</td>
            <td>26</td>
          </tr>

          <tr>
            <th>Feta</th>
            <td>2.2</td>
            <td>49</td>
            <td>4</td>
            <td>5</td>
            <td>34</td>
            <td>2</td>
            <td>46</td>
            <td>19</td>
            <td>2</td>
            <td>1</td>
            <td>21</td>
          </tr>

          <tr>
            <th>Cheddar</th>
            <td>3</td>
            <td>72</td>
            <td>4</td>
            <td>7</td>
            <td>51</td>
            <td>3</td>
            <td>26</td>
            <td>21</td>
            <td>2</td>
            <td>1</td>
            <td>20</td>
          </tr>

          <tr>
            <th>Mozzarella</th>
            <td>2.8</td>
            <td>51</td>
            <td>2</td>
            <td>5</td>
            <td>35</td>
            <td>2</td>
            <td>26</td>
            <td>19</td>
            <td>1</td>
            <td>1</td>
            <td>24</td>
          </tr>

          <tr>
            <th>Cottage</th>
            <td>3.3</td>
            <td>8</td>
            <td>0</td>
            <td>2</td>
            <td>16</td>
            <td>3</td>
            <td>15</td>
            <td>3</td>
            <td>1</td>
            <td>0</td>
            <td>14</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

export default CheeseTable;