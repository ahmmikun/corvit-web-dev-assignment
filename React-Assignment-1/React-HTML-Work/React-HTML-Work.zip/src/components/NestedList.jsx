function NestedList() {
  return (
    <div>
      <ul>
        <li>A</li>

        <li>
          B
          <ol>
            <li>B1</li>

            <li>
              B2
              <ul>
                <li>
                  B2a
                  <ul>
                    <li>B2aa</li>
                    <li>B2ab</li>
                  </ul>
                </li>

                <li>B2b</li>
                <li>B2c</li>
              </ul>
            </li>

            <li>
              B3
              <ol>
                <li>B31</li>
                <li>B32</li>
              </ol>
            </li>
          </ol>
        </li>

        <li>C</li>
      </ul>
    </div>
  );
}

export default NestedList;